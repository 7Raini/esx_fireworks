INSERT INTO `items` (`name`, `label`, `rare`, `can_remove`) VALUES
	('trailburst', 'Trailburst Firework', 0, 1),
	('fountain', 'Fountain Firework', 0, 1),
	('starburst', 'Starburst Firework', 0, 1),
	('shotburst', 'Shotburst Firework', 0, 1)
;
