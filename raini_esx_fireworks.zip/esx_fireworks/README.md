# esx_firework by Raini - Framework: ESX

## Download
[raini_firework]()

## Need support?
[Discord] https://discord.gg/FHPnq2THbE 

- join the server 
- open a ticket
- we solve your problem

# important
[Don't edit anything in the script if you have no idea]